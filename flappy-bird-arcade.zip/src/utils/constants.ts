/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BirdSkinConfig, BirdSkinId, DifficultyConfig, DifficultyMode, ThemeConfig, ThemeId } from '../types/game';

export const CANVAS_WIDTH = 360;
export const CANVAS_HEIGHT = 640;
export const GROUND_HEIGHT = 90;

export const BIRD_SKINS: Record<BirdSkinId, BirdSkinConfig> = {
  classic_ruby: {
    id: 'classic_ruby',
    name: 'Ruby Scarlet',
    primaryColor: '#ff3366',
    bellyColor: '#ff6688',
    outlineColor: '#ffffff',
    beakColor: '#ffcc00',
    wingColor: '#e11d48',
    featherColor: '#fda4af',
    description: 'The original vibrant red flyer with fierce determination.',
  },
  arcade_yellow: {
    id: 'arcade_yellow',
    name: 'Vintage Gold',
    primaryColor: '#facc15',
    bellyColor: '#fde047',
    outlineColor: '#ffffff',
    beakColor: '#f97316',
    wingColor: '#eab308',
    featherColor: '#fef08a',
    description: 'Nostalgic canary yellow hero of the classic arcade skies.',
  },
  cyber_cyan: {
    id: 'cyber_cyan',
    name: 'Cyber Hummingbird',
    primaryColor: '#06b6d4',
    bellyColor: '#67e8f9',
    outlineColor: '#ffffff',
    beakColor: '#a855f7',
    wingColor: '#0891b2',
    featherColor: '#a5f3fc',
    description: 'High-speed holographic cyan with luminous wing beats.',
  },
  phoenix_gold: {
    id: 'phoenix_gold',
    name: 'Solar Phoenix',
    primaryColor: '#f97316',
    bellyColor: '#fb923c',
    outlineColor: '#fffbeb',
    beakColor: '#e11d48',
    wingColor: '#ea580c',
    featherColor: '#fed7aa',
    description: 'Reborn from stardust with blazing solar feathers.',
  },
};

export const THEMES: Record<ThemeId, ThemeConfig> = {
  day: {
    id: 'day',
    name: 'Daylight Oasis',
    skyTop: '#4ec0ca',
    skyBottom: '#a0e0e6',
    pipeColorTop: '#73bf2e',
    pipeColorMid: '#9ce659',
    pipeColorBottom: '#55a021',
    pipeBorder: '#2e5a10',
    groundGrass: '#73bf2e',
    groundSoil: '#ded895',
    groundSoilPattern: '#c8bf73',
    cloudColor: 'rgba(255, 255, 255, 0.75)',
    starVisibility: 0,
    moonVisible: false,
  },
  sunset: {
    id: 'sunset',
    name: 'Twilight Horizon',
    skyTop: '#1e1b4b',
    skyBottom: '#f97316',
    pipeColorTop: '#047857',
    pipeColorMid: '#10b981',
    pipeColorBottom: '#064e3b',
    pipeBorder: '#022c22',
    groundGrass: '#059669',
    groundSoil: '#d97706',
    groundSoilPattern: '#b45309',
    cloudColor: 'rgba(254, 215, 170, 0.6)',
    starVisibility: 0.35,
    moonVisible: false,
  },
  night: {
    id: 'night',
    name: 'Midnight Stars',
    skyTop: '#090d16',
    skyBottom: '#1e293b',
    pipeColorTop: '#3b82f6',
    pipeColorMid: '#60a5fa',
    pipeColorBottom: '#1d4ed8',
    pipeBorder: '#172554',
    groundGrass: '#2563eb',
    groundSoil: '#334155',
    groundSoilPattern: '#1e293b',
    cloudColor: 'rgba(148, 163, 184, 0.3)',
    starVisibility: 0.9,
    moonVisible: true,
  },
};

export const DIFFICULTIES: Record<DifficultyMode, DifficultyConfig> = {
  casual: {
    id: 'casual',
    name: 'Casual',
    gap: 150,
    gravity: 0.22,
    jump: 4.5,
    dx: 1.8,
    spawnInterval: 105,
    description: 'Generous pipe gaps and gentle gravity. Great for practicing.',
  },
  classic: {
    id: 'classic',
    name: 'Classic',
    gap: 130,
    gravity: 0.25,
    jump: 4.8,
    dx: 2.0,
    spawnInterval: 100,
    description: 'The authentic, razor-sharp arcade physics balance.',
  },
  turbo: {
    id: 'turbo',
    name: 'Turbo',
    gap: 114,
    gravity: 0.28,
    jump: 5.1,
    dx: 2.5,
    spawnInterval: 85,
    description: 'Narrow clearances and swift pipe scrolling. High stakes!',
  },
};

export function getMedalTier(score: number): 'none' | 'bronze' | 'silver' | 'gold' | 'platinum' {
  if (score >= 100) return 'platinum';
  if (score >= 50) return 'gold';
  if (score >= 25) return 'silver';
  if (score >= 10) return 'bronze';
  return 'none';
}
