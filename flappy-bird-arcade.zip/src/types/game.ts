/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type GameState = 'GET_READY' | 'PLAYING' | 'PAUSED' | 'GAME_OVER';

export type BirdSkinId = 'classic_ruby' | 'arcade_yellow' | 'cyber_cyan' | 'phoenix_gold';

export interface BirdSkinConfig {
  id: BirdSkinId;
  name: string;
  primaryColor: string;
  bellyColor: string;
  outlineColor: string;
  beakColor: string;
  wingColor: string;
  featherColor: string;
  description: string;
}

export type ThemeId = 'day' | 'sunset' | 'night';

export interface ThemeConfig {
  id: ThemeId;
  name: string;
  skyTop: string;
  skyBottom: string;
  pipeColorTop: string;
  pipeColorMid: string;
  pipeColorBottom: string;
  pipeBorder: string;
  groundGrass: string;
  groundSoil: string;
  groundSoilPattern: string;
  cloudColor: string;
  starVisibility: number; // 0 to 1
  moonVisible: boolean;
}

export type DifficultyMode = 'casual' | 'classic' | 'turbo';

export interface DifficultyConfig {
  id: DifficultyMode;
  name: string;
  gap: number;
  gravity: number;
  jump: number;
  dx: number;
  spawnInterval: number; // frames
  description: string;
}

export interface GameScoreEntry {
  id: string;
  score: number;
  mode: DifficultyMode;
  date: string;
  medal: 'none' | 'bronze' | 'silver' | 'gold' | 'platinum';
}

export interface GameStats {
  highScore: number;
  casualHighScore: number;
  classicHighScore: number;
  turboHighScore: number;
  totalGames: number;
  totalPipes: number;
  recentRuns: GameScoreEntry[];
}
