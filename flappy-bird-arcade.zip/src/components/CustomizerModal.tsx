/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BirdSkinId, DifficultyMode, ThemeId } from '../types/game';
import { BIRD_SKINS, DIFFICULTIES, THEMES } from '../utils/constants';
import { Check, X } from 'lucide-react';

interface CustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedSkin: BirdSkinId;
  onSelectSkin: (id: BirdSkinId) => void;
  selectedTheme: ThemeId;
  onSelectTheme: (id: ThemeId) => void;
  selectedDifficulty: DifficultyMode;
  onSelectDifficulty: (id: DifficultyMode) => void;
}

export const CustomizerModal: React.FC<CustomizerModalProps> = ({
  isOpen,
  onClose,
  selectedSkin,
  onSelectSkin,
  selectedTheme,
  onSelectTheme,
  selectedDifficulty,
  onSelectDifficulty,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-700 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight">Hangar & Settings</h2>
            <p className="text-xs text-neutral-400">Customize your bird, arena backdrop, and flight difficulty</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Section 1: Bird Skins */}
          <div>
            <div className="text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-3">
              Bird Skins
            </div>
            <div className="grid grid-cols-2 gap-3">
              {(Object.keys(BIRD_SKINS) as BirdSkinId[]).map((skinKey) => {
                const skin = BIRD_SKINS[skinKey];
                const isSelected = selectedSkin === skinKey;
                return (
                  <button
                    key={skinKey}
                    onClick={() => onSelectSkin(skinKey)}
                    className={`flex items-start gap-3 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'border-amber-400 bg-amber-500/10 shadow-sm'
                        : 'border-neutral-800 bg-neutral-950/60 hover:border-neutral-700 hover:bg-neutral-800/40'
                    }`}
                  >
                    {/* Bird Avatar Icon */}
                    <div
                      className="w-10 h-10 rounded-full border-2 flex items-center justify-center shrink-0 relative shadow-inner"
                      style={{
                        backgroundColor: skin.primaryColor,
                        borderColor: skin.outlineColor,
                      }}
                    >
                      <div
                        className="w-2.5 h-2.5 rounded-full bg-white absolute top-2 right-2 flex items-center justify-center"
                      >
                        <div className="w-1 h-1 rounded-full bg-black" />
                      </div>
                      <div
                        className="w-3 h-2 rounded-xs absolute right-0 bottom-2"
                        style={{ backgroundColor: skin.beakColor }}
                      />
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold text-white truncate">{skin.name}</span>
                        {isSelected && <Check className="w-4 h-4 text-amber-400 shrink-0" />}
                      </div>
                      <p className="text-[11px] text-neutral-400 line-clamp-2 mt-0.5">{skin.description}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 2: Atmosphere & Themes */}
          <div>
            <div className="text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-3">
              Arena Theme
            </div>
            <div className="grid grid-cols-3 gap-3">
              {(Object.keys(THEMES) as ThemeId[]).map((themeKey) => {
                const theme = THEMES[themeKey];
                const isSelected = selectedTheme === themeKey;
                return (
                  <button
                    key={themeKey}
                    onClick={() => onSelectTheme(themeKey)}
                    className={`flex flex-col rounded-xl border overflow-hidden text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'border-emerald-400 ring-2 ring-emerald-400/20'
                        : 'border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    <div
                      className="h-14 w-full flex items-end p-2 relative"
                      style={{
                        background: `linear-gradient(to bottom, ${theme.skyTop}, ${theme.skyBottom})`,
                      }}
                    >
                      <div
                        className="h-3 w-4 rounded-t-xs"
                        style={{ backgroundColor: theme.pipeColorTop }}
                      />
                      <div
                        className="h-5 w-4 rounded-t-xs ml-auto"
                        style={{ backgroundColor: theme.pipeColorTop }}
                      />
                    </div>
                    <div className="p-2.5 bg-neutral-950 flex items-center justify-between">
                      <span className="text-xs font-medium text-white truncate">{theme.name}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 3: Difficulty Physics */}
          <div>
            <div className="text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-3">
              Flight Difficulty
            </div>
            <div className="grid grid-cols-3 gap-3">
              {(Object.keys(DIFFICULTIES) as DifficultyMode[]).map((diffKey) => {
                const diff = DIFFICULTIES[diffKey];
                const isSelected = selectedDifficulty === diffKey;
                return (
                  <button
                    key={diffKey}
                    onClick={() => onSelectDifficulty(diffKey)}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'border-sky-400 bg-sky-500/10 ring-2 ring-sky-400/20'
                        : 'border-neutral-800 bg-neutral-950/60 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-semibold text-white">{diff.name}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-sky-400" />}
                    </div>
                    <p className="text-[11px] text-neutral-400 line-clamp-3">{diff.description}</p>
                    <div className="mt-2 text-[10px] text-neutral-400">
                      Gap: <span className="font-mono text-neutral-200">{diff.gap}px</span> · Speed: <span className="font-mono text-neutral-200">{diff.dx}x</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-neutral-800 bg-neutral-950/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-neutral-200 hover:bg-white text-neutral-950 text-xs font-bold rounded-lg transition-colors cursor-pointer"
          >
            Apply & Close
          </button>
        </div>
      </div>
    </div>
  );
};
