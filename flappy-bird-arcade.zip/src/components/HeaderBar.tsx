/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Palette, Volume2, VolumeX, HelpCircle, Trophy } from 'lucide-react';

interface HeaderBarProps {
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenCustomizer: () => void;
  onOpenHowToPlay: () => void;
  onToggleScores: () => void;
  showingScores: boolean;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  isMuted,
  onToggleMute,
  onOpenCustomizer,
  onOpenHowToPlay,
  onToggleScores,
  showingScores,
}) => {
  return (
    <header className="w-full flex items-center justify-between px-4 sm:px-8 py-3.5 border-b border-neutral-800 bg-neutral-950/80 backdrop-blur-md sticky top-0 z-40">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-2">
        <span className="text-base sm:text-lg font-bold tracking-tight text-white font-['Outfit'] flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-emerald-400 inline-block shadow-sm shadow-emerald-400/50" />
          Flappy Bird Arcade
        </span>
      </div>

      {/* Zone 2: Clean text navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-neutral-400">
        <button
          onClick={onOpenHowToPlay}
          className="hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer"
        >
          <HelpCircle className="w-3.5 h-3.5" />
          <span>Flight Manual</span>
        </button>
        <button
          onClick={onOpenCustomizer}
          className="hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer"
        >
          <Palette className="w-3.5 h-3.5" />
          <span>Skins & Arena</span>
        </button>
        <button
          onClick={onToggleScores}
          className={`hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer ${
            showingScores ? 'text-amber-400' : ''
          }`}
        >
          <Trophy className="w-3.5 h-3.5" />
          <span>Hall of Fame</span>
        </button>
      </nav>

      {/* Zone 3: 1-2 primary actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={onToggleMute}
          title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
          className={`p-2 rounded-lg border transition-colors cursor-pointer ${
            isMuted
              ? 'bg-neutral-900 border-neutral-800 text-neutral-500 hover:text-white'
              : 'bg-neutral-800 border-neutral-700 text-emerald-400 hover:bg-neutral-750'
          }`}
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>

        <button
          onClick={onOpenCustomizer}
          className="px-3.5 py-2 text-xs font-semibold text-neutral-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer whitespace-nowrap"
        >
          <Palette className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Customize</span>
        </button>
      </div>
    </header>
  );
};
