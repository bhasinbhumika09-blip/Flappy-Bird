/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Award, Gamepad2, MousePointer, ShieldAlert, X } from 'lucide-react';

interface HowToPlayModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-700 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Gamepad2 className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-white tracking-tight">Flight Manual & Controls</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-xs text-neutral-300">
          {/* Controls */}
          <div>
            <div className="font-semibold text-white uppercase tracking-wider text-[11px] mb-2.5">
              Flight Controls
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 flex items-start gap-2.5">
                <kbd className="px-2 py-1 bg-neutral-800 border border-neutral-700 rounded text-neutral-200 font-mono text-[11px] shrink-0">
                  Space
                </kbd>
                <div>
                  <div className="font-medium text-white">Flap / Wing Lift</div>
                  <div className="text-[11px] text-neutral-400">Also Arrow Up or 'W'</div>
                </div>
              </div>
              <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 flex items-start gap-2.5">
                <MousePointer className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-medium text-white">Tap / Click</div>
                  <div className="text-[11px] text-neutral-400">Anywhere on canvas</div>
                </div>
              </div>
            </div>
          </div>

          {/* Objectives */}
          <div>
            <div className="font-semibold text-white uppercase tracking-wider text-[11px] mb-2">
              Rules & Obstacles
            </div>
            <ul className="space-y-1.5 text-neutral-400">
              <li className="flex items-start gap-2">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span>Navigate between the upper and lower pipes without hitting them or the ground.</span>
              </li>
              <li className="flex items-start gap-2">
                <Award className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>Each pair of pipes successfully passed awards 1 point.</span>
              </li>
            </ul>
          </div>

          {/* Medal Tiers */}
          <div>
            <div className="font-semibold text-white uppercase tracking-wider text-[11px] mb-2">
              Arcade Medal Benchmarks
            </div>
            <div className="grid grid-cols-4 gap-2 text-center">
              <div className="bg-neutral-950 p-2.5 rounded-lg border border-amber-900/40">
                <div className="text-amber-600 font-bold text-xs">Bronze</div>
                <div className="font-mono text-white mt-1">10+ pts</div>
              </div>
              <div className="bg-neutral-950 p-2.5 rounded-lg border border-neutral-700/60">
                <div className="text-slate-300 font-bold text-xs">Silver</div>
                <div className="font-mono text-white mt-1">25+ pts</div>
              </div>
              <div className="bg-neutral-950 p-2.5 rounded-lg border border-yellow-500/40">
                <div className="text-yellow-400 font-bold text-xs">Gold</div>
                <div className="font-mono text-white mt-1">50+ pts</div>
              </div>
              <div className="bg-neutral-950 p-2.5 rounded-lg border border-cyan-500/40">
                <div className="text-cyan-300 font-bold text-xs">Platinum</div>
                <div className="font-mono text-white mt-1">100+ pts</div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-neutral-800 bg-neutral-950 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 text-xs font-bold rounded-lg transition-colors cursor-pointer"
          >
            Got it, Let's Fly!
          </button>
        </div>
      </div>
    </div>
  );
};
