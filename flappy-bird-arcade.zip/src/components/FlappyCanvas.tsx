/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useCallback } from 'react';
import { BirdSkinId, DifficultyMode, GameState, ThemeId } from '../types/game';
import { BIRD_SKINS, CANVAS_HEIGHT, CANVAS_WIDTH, DIFFICULTIES, GROUND_HEIGHT, THEMES } from '../utils/constants';
import { sound } from '../utils/audio';

interface FlappyCanvasProps {
  gameState: GameState;
  onGameStateChange: (newState: GameState) => void;
  onScoreUpdate: (newScore: number) => void;
  onGameOver: (finalScore: number) => void;
  skinId: BirdSkinId;
  themeId: ThemeId;
  difficulty: DifficultyMode;
  isPaused: boolean;
}

interface Pipe {
  x: number;
  y: number;
  gap: number;
  passed: boolean;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  color: string;
  rotation: number;
  vRot: number;
}

interface FloatingScore {
  x: number;
  y: number;
  text: string;
  alpha: number;
  vy: number;
}

export const FlappyCanvas: React.FC<FlappyCanvasProps> = ({
  gameState,
  onGameStateChange,
  onScoreUpdate,
  onGameOver,
  skinId,
  themeId,
  difficulty,
  isPaused,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Mutable game state held in refs so animation loop has zero lag / no stale closures
  const stateRef = useRef({
    frames: 0,
    score: 0,
    gameState,
    isPaused,
    skinId,
    themeId,
    difficulty,
    shake: 0,
    groundOffset: 0,
    cloudOffset: 0,
  });

  // Keep stateRef up to date with props
  useEffect(() => {
    stateRef.current.gameState = gameState;
    stateRef.current.isPaused = isPaused;
    stateRef.current.skinId = skinId;
    stateRef.current.themeId = themeId;
    stateRef.current.difficulty = difficulty;
  }, [gameState, isPaused, skinId, themeId, difficulty]);

  // Game internal entities
  const birdRef = useRef({
    x: 60,
    y: 250,
    r: 14,
    velocity: 0,
    wingAngle: 0,
    flapSpeed: 0.2,
  });

  const pipesRef = useRef<Pipe[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const floatingScoresRef = useRef<FloatingScore[]>([]);

  // Jump / Action handler
  const handleFlap = useCallback(() => {
    const s = stateRef.current;
    if (s.isPaused) return;

    if (s.gameState === 'GET_READY') {
      s.gameState = 'PLAYING';
      onGameStateChange('PLAYING');
      birdRef.current.velocity = -DIFFICULTIES[s.difficulty].jump;
      sound.playFlap();
      createFlapParticles();
    } else if (s.gameState === 'PLAYING') {
      birdRef.current.velocity = -DIFFICULTIES[s.difficulty].jump;
      sound.playFlap();
      createFlapParticles();
    } else if (s.gameState === 'GAME_OVER') {
      // Reset game
      resetGame();
      s.gameState = 'GET_READY';
      onGameStateChange('GET_READY');
    }
  }, [onGameStateChange]);

  const resetGame = () => {
    const s = stateRef.current;
    s.score = 0;
    s.frames = 0;
    s.shake = 0;
    onScoreUpdate(0);
    birdRef.current.x = 60;
    birdRef.current.y = 250;
    birdRef.current.velocity = 0;
    birdRef.current.wingAngle = 0;
    pipesRef.current = [];
    particlesRef.current = [];
    floatingScoresRef.current = [];
  };

  const createFlapParticles = () => {
    const b = birdRef.current;
    const skin = BIRD_SKINS[stateRef.current.skinId];
    for (let i = 0; i < 3; i++) {
      particlesRef.current.push({
        x: b.x - b.r + (Math.random() * 4 - 2),
        y: b.y + (Math.random() * 6 - 3),
        vx: -(1.5 + Math.random() * 1.5),
        vy: (Math.random() - 0.5) * 1.5,
        size: 3 + Math.random() * 2.5,
        alpha: 0.8,
        color: skin.featherColor,
        rotation: Math.random() * Math.PI,
        vRot: (Math.random() - 0.5) * 0.1,
      });
    }
  };

  const triggerCollision = (finalScore: number) => {
    const s = stateRef.current;
    if (s.gameState === 'GAME_OVER') return;

    s.gameState = 'GAME_OVER';
    s.shake = 12; // Screen shake
    sound.playHit();
    setTimeout(() => sound.playFall(), 140);

    // Burst feathers
    const b = birdRef.current;
    const skin = BIRD_SKINS[s.skinId];
    for (let i = 0; i < 16; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 2 + Math.random() * 4;
      particlesRef.current.push({
        x: b.x,
        y: b.y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.5,
        size: 3.5 + Math.random() * 3,
        alpha: 1,
        color: i % 2 === 0 ? skin.primaryColor : skin.featherColor,
        rotation: Math.random() * Math.PI,
        vRot: (Math.random() - 0.5) * 0.2,
      });
    }

    onGameOver(finalScore);
  };

  // Keyboard controls
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
        e.preventDefault();
        handleFlap();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleFlap]);

  // Main Canvas Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Retina DPI Setup
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = CANVAS_WIDTH * dpr;
    canvas.height = CANVAS_HEIGHT * dpr;
    ctx.scale(dpr, dpr);

    let animationFrameId: number;

    const render = () => {
      const s = stateRef.current;
      const bird = birdRef.current;
      const skin = BIRD_SKINS[s.skinId];
      const theme = THEMES[s.themeId];
      const diff = DIFFICULTIES[s.difficulty];

      // Update game physics if not paused
      if (!s.isPaused) {
        // Screen shake decay
        if (s.shake > 0) {
          s.shake *= 0.85;
          if (s.shake < 0.2) s.shake = 0;
        }

        // Bird update
        if (s.gameState === 'GET_READY') {
          bird.y = 250 + Math.sin(s.frames / 12) * 6;
          bird.velocity = 0;
          bird.wingAngle = Math.sin(s.frames / 8) * 0.4;
          s.groundOffset = (s.groundOffset + diff.dx) % 24;
          s.cloudOffset = (s.cloudOffset + 0.3) % CANVAS_WIDTH;
        } else if (s.gameState === 'PLAYING') {
          bird.velocity += diff.gravity;
          bird.y += bird.velocity;
          bird.wingAngle = bird.velocity < 0 ? Math.sin(s.frames / 4) * 0.6 : -0.2;

          s.groundOffset = (s.groundOffset + diff.dx) % 24;
          s.cloudOffset = (s.cloudOffset + 0.3) % CANVAS_WIDTH;

          // Ground collision
          if (bird.y + bird.r >= CANVAS_HEIGHT - GROUND_HEIGHT) {
            bird.y = CANVAS_HEIGHT - GROUND_HEIGHT - bird.r;
            triggerCollision(s.score);
          }

          // Ceiling limit
          if (bird.y - bird.r <= 0) {
            bird.y = bird.r;
            bird.velocity = 0;
          }

          // Pipe generation
          if (s.frames % diff.spawnInterval === 0) {
            const minHeight = 60;
            const maxHeight = CANVAS_HEIGHT - GROUND_HEIGHT - diff.gap - 60;
            const pipeY = Math.floor(Math.random() * (maxHeight - minHeight + 1)) + minHeight;
            pipesRef.current.push({
              x: CANVAS_WIDTH,
              y: pipeY,
              gap: diff.gap,
              passed: false,
            });
          }

          // Update pipes
          const pipes = pipesRef.current;
          for (let i = 0; i < pipes.length; i++) {
            const p = pipes[i];
            p.x -= diff.dx;
            const bottomY = p.y + p.gap;
            const pipeWidth = 54;

            // Hitbox checks (with slight forgiveness margin for fair play)
            const birdMargin = 2.5;
            const birdLeft = bird.x - bird.r + birdMargin;
            const birdRight = bird.x + bird.r - birdMargin;
            const birdTop = bird.y - bird.r + birdMargin;
            const birdBottom = bird.y + bird.r - birdMargin;

            // Top Pipe
            if (birdRight > p.x && birdLeft < p.x + pipeWidth && birdTop < p.y) {
              triggerCollision(s.score);
            }

            // Bottom Pipe
            if (birdRight > p.x && birdLeft < p.x + pipeWidth && birdBottom > bottomY) {
              triggerCollision(s.score);
            }

            // Score update
            if (p.x + pipeWidth < bird.x - bird.r && !p.passed) {
              p.passed = true;
              s.score += 1;
              onScoreUpdate(s.score);
              sound.playScore();

              floatingScoresRef.current.push({
                x: bird.x + 10,
                y: bird.y - 15,
                text: '+1',
                alpha: 1,
                vy: -1.2,
              });
            }

            // Remove offscreen
            if (p.x + pipeWidth <= -10) {
              pipes.splice(i, 1);
              i--;
            }
          }
        } else if (s.gameState === 'GAME_OVER') {
          // Bird falls to ground on game over
          if (bird.y + bird.r < CANVAS_HEIGHT - GROUND_HEIGHT) {
            bird.velocity += diff.gravity * 1.2;
            bird.y += bird.velocity;
          } else {
            bird.y = CANVAS_HEIGHT - GROUND_HEIGHT - bird.r;
          }
        }

        // Update particles
        const particles = particlesRef.current;
        for (let i = 0; i < particles.length; i++) {
          const pt = particles[i];
          pt.x += pt.vx;
          pt.y += pt.vy;
          pt.vy += 0.08; // gravity
          pt.alpha -= 0.02;
          pt.rotation += pt.vRot;
          if (pt.alpha <= 0) {
            particles.splice(i, 1);
            i--;
          }
        }

        // Update floating score indicators
        const fScores = floatingScoresRef.current;
        for (let i = 0; i < fScores.length; i++) {
          const fs = fScores[i];
          fs.y += fs.vy;
          fs.alpha -= 0.025;
          if (fs.alpha <= 0) {
            fScores.splice(i, 1);
            i--;
          }
        }

        s.frames++;
      }

      // ================= DRAWING PASS =================
      ctx.save();

      // Screen shake translation
      if (s.shake > 0) {
        const sx = (Math.random() - 0.5) * s.shake;
        const sy = (Math.random() - 0.5) * s.shake;
        ctx.translate(sx, sy);
      }

      // 1. Sky Gradient
      const skyGrad = ctx.createLinearGradient(0, 0, 0, CANVAS_HEIGHT);
      skyGrad.addColorStop(0, theme.skyTop);
      skyGrad.addColorStop(1, theme.skyBottom);
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // 2. Stars (if night)
      if (theme.starVisibility > 0) {
        ctx.fillStyle = `rgba(255, 255, 255, ${theme.starVisibility})`;
        const starCoords = [
          [35, 45, 1.5], [80, 110, 1], [140, 70, 2], [220, 40, 1.2],
          [280, 95, 1.8], [330, 60, 1], [70, 180, 1.5], [300, 190, 1.3],
          [180, 160, 1], [40, 280, 1.2], [320, 290, 1.5]
        ];
        starCoords.forEach(([sx, sy, sr]) => {
          ctx.beginPath();
          ctx.arc(sx, sy, sr, 0, Math.PI * 2);
          ctx.fill();
        });
      }

      // 3. Moon (if visible)
      if (theme.moonVisible) {
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(290, 85, 24, 0, Math.PI * 2);
        ctx.fill();
        // Moon craters
        ctx.fillStyle = '#fde047';
        ctx.beginPath();
        ctx.arc(282, 80, 4, 0, Math.PI * 2);
        ctx.arc(298, 92, 5, 0, Math.PI * 2);
        ctx.arc(288, 96, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      // 4. Distant City Skyline / Hills (Parallax layer)
      ctx.fillStyle = theme.id === 'night' ? 'rgba(15, 23, 42, 0.7)' : theme.id === 'sunset' ? 'rgba(88, 28, 135, 0.4)' : 'rgba(78, 168, 177, 0.45)';
      ctx.beginPath();
      ctx.moveTo(0, CANVAS_HEIGHT - GROUND_HEIGHT);
      ctx.lineTo(0, CANVAS_HEIGHT - GROUND_HEIGHT - 65);
      ctx.bezierCurveTo(70, CANVAS_HEIGHT - GROUND_HEIGHT - 100, 140, CANVAS_HEIGHT - GROUND_HEIGHT - 40, 200, CANVAS_HEIGHT - GROUND_HEIGHT - 75);
      ctx.bezierCurveTo(270, CANVAS_HEIGHT - GROUND_HEIGHT - 110, 320, CANVAS_HEIGHT - GROUND_HEIGHT - 55, CANVAS_WIDTH, CANVAS_HEIGHT - GROUND_HEIGHT - 70);
      ctx.lineTo(CANVAS_WIDTH, CANVAS_HEIGHT - GROUND_HEIGHT);
      ctx.closePath();
      ctx.fill();

      // 5. Stylized Clouds (Parallax moving)
      ctx.fillStyle = theme.cloudColor;
      const drawCloud = (cx: number, cy: number, scale: number) => {
        ctx.save();
        ctx.translate(cx, cy);
        ctx.scale(scale, scale);
        ctx.beginPath();
        ctx.arc(0, 0, 16, 0, Math.PI * 2);
        ctx.arc(15, -6, 20, 0, Math.PI * 2);
        ctx.arc(35, 0, 17, 0, Math.PI * 2);
        ctx.arc(20, 8, 14, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      };

      const c1X = (100 - s.cloudOffset + CANVAS_WIDTH) % CANVAS_WIDTH;
      const c2X = (260 - s.cloudOffset + CANVAS_WIDTH) % CANVAS_WIDTH;
      const c3X = (420 - s.cloudOffset + CANVAS_WIDTH) % CANVAS_WIDTH;
      drawCloud(c1X, 110, 1.2);
      drawCloud(c2X, 70, 0.9);
      drawCloud(c3X, 150, 1.0);

      // 6. Pipes with 3D Arcade Highlight & Beveled Rim Collar
      const pipeWidth = 54;
      const lipHeight = 24;
      const lipOverhang = 3;

      pipesRef.current.forEach((p) => {
        const topPipeHeight = p.y;
        const bottomPipeY = p.y + p.gap;
        const bottomPipeHeight = CANVAS_HEIGHT - bottomPipeY - GROUND_HEIGHT;

        // Gradient for pipes
        const pipeGrad = ctx.createLinearGradient(p.x, 0, p.x + pipeWidth, 0);
        pipeGrad.addColorStop(0, theme.pipeColorTop);
        pipeGrad.addColorStop(0.35, theme.pipeColorMid);
        pipeGrad.addColorStop(0.7, theme.pipeColorTop);
        pipeGrad.addColorStop(1, theme.pipeColorBottom);

        const lipGrad = ctx.createLinearGradient(p.x - lipOverhang, 0, p.x + pipeWidth + lipOverhang, 0);
        lipGrad.addColorStop(0, theme.pipeColorTop);
        lipGrad.addColorStop(0.35, theme.pipeColorMid);
        lipGrad.addColorStop(0.7, theme.pipeColorTop);
        lipGrad.addColorStop(1, theme.pipeColorBottom);

        ctx.fillStyle = pipeGrad;
        ctx.strokeStyle = theme.pipeBorder;
        ctx.lineWidth = 2.5;

        // TOP PIPE SHAFT
        if (topPipeHeight > lipHeight) {
          ctx.fillRect(p.x, 0, pipeWidth, topPipeHeight - lipHeight);
          ctx.strokeRect(p.x, 0, pipeWidth, topPipeHeight - lipHeight);
        }

        // TOP PIPE LIP (COLLAR)
        ctx.fillStyle = lipGrad;
        ctx.fillRect(p.x - lipOverhang, topPipeHeight - lipHeight, pipeWidth + lipOverhang * 2, lipHeight);
        ctx.strokeRect(p.x - lipOverhang, topPipeHeight - lipHeight, pipeWidth + lipOverhang * 2, lipHeight);

        // BOTTOM PIPE SHAFT
        ctx.fillStyle = pipeGrad;
        ctx.fillRect(p.x, bottomPipeY + lipHeight, pipeWidth, bottomPipeHeight - lipHeight);
        ctx.strokeRect(p.x, bottomPipeY + lipHeight, pipeWidth, bottomPipeHeight - lipHeight);

        // BOTTOM PIPE LIP (COLLAR)
        ctx.fillStyle = lipGrad;
        ctx.fillRect(p.x - lipOverhang, bottomPipeY, pipeWidth + lipOverhang * 2, lipHeight);
        ctx.strokeRect(p.x - lipOverhang, bottomPipeY, pipeWidth + lipOverhang * 2, lipHeight);

        // High gloss highlight line
        ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
        ctx.fillRect(p.x + 8, 0, 4, topPipeHeight);
        ctx.fillRect(p.x + 8, bottomPipeY, 4, bottomPipeHeight);
      });

      // 7. Ground / Foreground (fg)
      const groundY = CANVAS_HEIGHT - GROUND_HEIGHT;
      // Soil base
      ctx.fillStyle = theme.groundSoil;
      ctx.fillRect(0, groundY, CANVAS_WIDTH, GROUND_HEIGHT);

      // Grass top stripe
      ctx.fillStyle = theme.groundGrass;
      ctx.fillRect(0, groundY, CANVAS_WIDTH, 14);

      // Dark border on top of grass
      ctx.fillStyle = '#1e3a10';
      ctx.fillRect(0, groundY, CANVAS_WIDTH, 2);

      // Moving grass blades pattern
      ctx.fillStyle = theme.groundSoilPattern;
      const patternWidth = 24;
      for (let x = -s.groundOffset; x < CANVAS_WIDTH + patternWidth; x += patternWidth) {
        ctx.beginPath();
        ctx.moveTo(x, groundY + 14);
        ctx.lineTo(x + 10, groundY + 24);
        ctx.lineTo(x + 14, groundY + 24);
        ctx.lineTo(x + 4, groundY + 14);
        ctx.closePath();
        ctx.fill();

        // Decorative stone / pebble specks in soil
        ctx.fillRect(x + 6, groundY + 45, 5, 3);
        ctx.fillRect(x + 16, groundY + 68, 6, 4);
      }

      // 8. Particles (Feathers & sparks)
      particlesRef.current.forEach((pt) => {
        ctx.save();
        ctx.translate(pt.x, pt.y);
        ctx.rotate(pt.rotation);
        ctx.globalAlpha = pt.alpha;
        ctx.fillStyle = pt.color;
        // Oval feather shape
        ctx.beginPath();
        ctx.ellipse(0, 0, pt.size, pt.size * 0.5, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // 9. Bird Drawing with Detailed Wing Flap & Expressive Eyes
      ctx.save();
      ctx.translate(bird.x, bird.y);

      // Tilt rotation: clamps between -25 deg (nose up) and +75 deg (nose down)
      const maxTiltDown = (75 * Math.PI) / 180;
      const maxTiltUp = (-25 * Math.PI) / 180;
      const rotation = Math.min(maxTiltDown, Math.max(maxTiltUp, (bird.velocity * 4.2 * Math.PI) / 180));
      ctx.rotate(rotation);

      // Bird Tail
      ctx.fillStyle = skin.wingColor;
      ctx.beginPath();
      ctx.moveTo(-bird.r, -2);
      ctx.lineTo(-bird.r - 8, -6);
      ctx.lineTo(-bird.r - 6, 2);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = skin.outlineColor;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Bird Body (Sphere)
      ctx.fillStyle = skin.primaryColor;
      ctx.beginPath();
      ctx.arc(0, 0, bird.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = skin.outlineColor;
      ctx.stroke();

      // Belly Patch
      ctx.fillStyle = skin.bellyColor;
      ctx.beginPath();
      ctx.ellipse(-2, 4, bird.r * 0.7, bird.r * 0.5, Math.PI / 8, 0, Math.PI * 2);
      ctx.fill();

      // Bird Wing (Animated)
      ctx.save();
      ctx.translate(-3, 0);
      ctx.rotate(bird.wingAngle);
      ctx.fillStyle = skin.wingColor;
      ctx.beginPath();
      ctx.ellipse(0, 0, 8, 5, -Math.PI / 12, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = skin.outlineColor;
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.restore();

      // Eye (White)
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(5, -4, 4.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Pupil (Black + White glint)
      ctx.fillStyle = '#000000';
      ctx.beginPath();
      ctx.arc(6.5, -4, 2, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(6, -5, 0.9, 0, Math.PI * 2);
      ctx.fill();

      // Beak
      ctx.fillStyle = skin.beakColor;
      ctx.beginPath();
      ctx.moveTo(8, -1);
      ctx.lineTo(17, 3);
      ctx.lineTo(8, 7);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#7c2d12';
      ctx.lineWidth = 1.2;
      ctx.stroke();

      // Beak line (lips)
      ctx.strokeStyle = '#451a03';
      ctx.beginPath();
      ctx.moveTo(8, 3);
      ctx.lineTo(15, 3);
      ctx.stroke();

      ctx.restore();

      // 10. Floating Score Popups
      floatingScoresRef.current.forEach((fs) => {
        ctx.save();
        ctx.globalAlpha = fs.alpha;
        ctx.fillStyle = '#fef08a';
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 2.5;
        ctx.font = 'bold 20px "Press Start 2P", sans-serif';
        ctx.textAlign = 'center';
        ctx.strokeText(fs.text, fs.x, fs.y);
        ctx.fillText(fs.text, fs.x, fs.y);
        ctx.restore();
      });

      // 11. Canvas HUD Overlay
      if (s.gameState === 'GET_READY') {
        // Ready Title
        ctx.fillStyle = '#ffffff';
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 3;
        ctx.font = 'bold 26px "Press Start 2P", monospace';
        ctx.textAlign = 'center';
        ctx.strokeText('FLAPPY', CANVAS_WIDTH / 2, 160);
        ctx.fillText('FLAPPY', CANVAS_WIDTH / 2, 160);

        ctx.fillStyle = '#facc15';
        ctx.strokeText('BIRD', CANVAS_WIDTH / 2, 195);
        ctx.fillText('BIRD', CANVAS_WIDTH / 2, 195);

        // Tap Prompt Banner
        const pulse = (Math.sin(s.frames / 12) + 1) * 0.5;
        ctx.fillStyle = `rgba(255, 255, 255, ${0.85 + pulse * 0.15})`;
        ctx.font = '600 14px "Outfit", sans-serif';
        ctx.fillText('TAP OR PRESS SPACE TO FLY', CANVAS_WIDTH / 2, 335);

        // Difficulty label
        ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
        ctx.font = '500 12px "Outfit", sans-serif';
        ctx.fillText(`MODE: ${diff.name.toUpperCase()}`, CANVAS_WIDTH / 2, 360);
      } else if (s.gameState === 'PLAYING') {
        // Clean In-Game Score
        ctx.fillStyle = '#ffffff';
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 4;
        ctx.font = 'bold 36px "Press Start 2P", monospace';
        ctx.textAlign = 'center';
        ctx.strokeText(String(s.score), CANVAS_WIDTH / 2, 70);
        ctx.fillText(String(s.score), CANVAS_WIDTH / 2, 70);
      }

      ctx.restore();

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [onGameOver, onScoreUpdate]);

  return (
    <div
      className="relative flex items-center justify-center cursor-pointer select-none"
      onClick={handleFlap}
      onTouchStart={(e) => {
        e.preventDefault();
        handleFlap();
      }}
    >
      <canvas
        ref={canvasRef}
        className="w-[360px] h-[640px] max-w-full max-h-[80vh] sm:max-h-[85vh] rounded-2xl shadow-2xl border-4 border-neutral-800 bg-neutral-900 object-contain touch-none"
        style={{
          aspectRatio: '360 / 640',
        }}
      />
    </div>
  );
};
