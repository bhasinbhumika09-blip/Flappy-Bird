/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { GameStats } from '../types/game';
import { Award, Flame, History, Trophy } from 'lucide-react';

interface ScoreboardPanelProps {
  stats: GameStats;
  onClearHistory?: () => void;
}

export const ScoreboardPanel: React.FC<ScoreboardPanelProps> = ({ stats, onClearHistory }) => {
  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-xl flex flex-col h-full">
      <div className="flex items-center justify-between pb-4 border-b border-neutral-800 mb-4">
        <div className="flex items-center gap-2">
          <Trophy className="w-5 h-5 text-amber-400" />
          <h3 className="font-bold text-sm text-white tracking-wide uppercase">Arcade Hall of Fame</h3>
        </div>
        <span className="text-xs text-neutral-400 font-mono tabular-nums">
          {stats.totalGames} runs
        </span>
      </div>

      {/* Top 3 Difficulty Records */}
      <div className="grid grid-cols-3 gap-2.5 mb-5">
        <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 flex flex-col">
          <span className="text-[10px] text-neutral-400 font-medium uppercase tracking-wider">
            Classic
          </span>
          <span className="text-2xl font-bold text-white font-mono tabular-nums mt-1">
            {stats.classicHighScore || 0}
          </span>
          <span className="text-[10px] text-amber-500/80 mt-auto font-medium">Standard</span>
        </div>

        <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 flex flex-col">
          <span className="text-[10px] text-neutral-400 font-medium uppercase tracking-wider">
            Casual
          </span>
          <span className="text-2xl font-bold text-white font-mono tabular-nums mt-1">
            {stats.casualHighScore || 0}
          </span>
          <span className="text-[10px] text-sky-400/80 mt-auto font-medium">Float</span>
        </div>

        <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 flex flex-col">
          <span className="text-[10px] text-neutral-400 font-medium uppercase tracking-wider">
            Turbo
          </span>
          <span className="text-2xl font-bold text-white font-mono tabular-nums mt-1">
            {stats.turboHighScore || 0}
          </span>
          <span className="text-[10px] text-rose-400/80 mt-auto font-medium">High Speed</span>
        </div>
      </div>

      {/* Career Metrics */}
      <div className="bg-neutral-950/70 border border-neutral-800 rounded-xl p-3.5 mb-5 space-y-2 text-xs">
        <div className="flex items-center justify-between text-neutral-300">
          <span className="flex items-center gap-1.5 text-neutral-400">
            <Flame className="w-3.5 h-3.5 text-orange-400" />
            Total Pipes Cleared
          </span>
          <span className="font-mono font-bold text-white tabular-nums">
            {stats.totalPipes.toLocaleString()}
          </span>
        </div>
        <div className="flex items-center justify-between text-neutral-300">
          <span className="flex items-center gap-1.5 text-neutral-400">
            <Award className="w-3.5 h-3.5 text-yellow-400" />
            Overall Best Flight
          </span>
          <span className="font-mono font-bold text-amber-400 tabular-nums">
            {stats.highScore}
          </span>
        </div>
      </div>

      {/* Recent Flights History */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-neutral-400 uppercase tracking-wider">
          <History className="w-3.5 h-3.5" />
          Recent Flights
        </div>
        {stats.recentRuns.length > 0 && onClearHistory && (
          <button
            onClick={onClearHistory}
            className="text-[11px] text-neutral-500 hover:text-neutral-400 cursor-pointer"
          >
            Clear
          </button>
        )}
      </div>

      <div className="space-y-1.5 overflow-y-auto max-h-[170px] pr-1">
        {stats.recentRuns.length === 0 ? (
          <div className="text-xs text-neutral-500 py-6 text-center italic">
            No flight logs yet. Take to the skies!
          </div>
        ) : (
          stats.recentRuns.slice(0, 6).map((run) => (
            <div
              key={run.id}
              className="flex items-center justify-between px-3 py-2 bg-neutral-950/60 border border-neutral-800/80 rounded-lg text-xs"
            >
              <div className="flex items-center gap-2">
                <span className="capitalize text-neutral-400 text-[11px]">{run.mode}</span>
                <span className="text-neutral-600">·</span>
                <span className="text-[10px] text-neutral-500">{run.date}</span>
              </div>
              <div className="flex items-center gap-2">
                {run.medal !== 'none' && (
                  <span className="text-[10px] font-bold uppercase text-amber-400">
                    {run.medal}
                  </span>
                )}
                <span className="font-mono font-bold text-white tabular-nums">
                  {run.score} pts
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
