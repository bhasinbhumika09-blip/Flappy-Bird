/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { Award, RotateCcw, Share2, Sparkles, Trophy } from 'lucide-react';
import { DifficultyMode } from '../types/game';
import { getMedalTier } from '../utils/constants';

interface GameOverModalProps {
  score: number;
  highScore: number;
  isNewHigh: boolean;
  difficulty: DifficultyMode;
  onRestart: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  highScore,
  isNewHigh,
  difficulty,
  onRestart,
}) => {
  const [animatedScore, setAnimatedScore] = useState(0);
  const [copied, setCopied] = useState(false);
  const medal = getMedalTier(score);

  // Score count-up effect
  useEffect(() => {
    let start = 0;
    const duration = Math.min(800, Math.max(300, score * 40));
    const stepTime = Math.max(16, duration / Math.max(1, score));
    const timer = setInterval(() => {
      start++;
      if (start >= score) {
        setAnimatedScore(score);
        clearInterval(timer);
      } else {
        setAnimatedScore(start);
      }
    }, stepTime);

    if (isNewHigh && score > 0) {
      try {
        confetti({
          particleCount: 60,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#facc15', '#f97316', '#38bdf8', '#4ade80'],
        });
      } catch {
        // ignore
      }
    }

    return () => clearInterval(timer);
  }, [score, isNewHigh]);

  const handleShare = () => {
    const text = `I scored ${score} in Flappy Bird Arcade on ${difficulty.toUpperCase()} mode! 🐦 Best: ${highScore}. Can you beat it?`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const getMedalColor = () => {
    switch (medal) {
      case 'platinum':
        return 'bg-gradient-to-br from-cyan-300 via-sky-100 to-indigo-300 text-slate-900 border-cyan-400';
      case 'gold':
        return 'bg-gradient-to-br from-yellow-300 via-amber-400 to-amber-600 text-amber-950 border-yellow-200';
      case 'silver':
        return 'bg-gradient-to-br from-slate-200 via-neutral-300 to-slate-400 text-slate-800 border-slate-100';
      case 'bronze':
        return 'bg-gradient-to-br from-amber-600 via-orange-700 to-amber-900 text-amber-100 border-amber-500';
      default:
        return 'bg-neutral-800 text-neutral-400 border-neutral-700';
    }
  };

  return (
    <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-20 rounded-2xl animate-in fade-in zoom-in-95 duration-200">
      <div className="bg-neutral-900 border border-neutral-700 w-full max-w-[320px] rounded-xl p-5 shadow-2xl flex flex-col items-center text-center">
        {/* Header */}
        <h2 className="text-xl font-bold tracking-tight text-white mb-1 font-['Press_Start_2P'] text-sm sm:text-base">
          GAME OVER
        </h2>
        <div className="text-xs text-neutral-400 mb-4 capitalize">
          Mode: {difficulty}
        </div>

        {/* Score Board Box */}
        <div className="w-full bg-neutral-950 border border-neutral-800 rounded-lg p-4 mb-4 relative">
          {isNewHigh && score > 0 && (
            <div className="absolute -top-3 right-3 bg-amber-500 text-neutral-950 text-[10px] font-bold px-2 py-0.5 rounded shadow flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              NEW BEST
            </div>
          )}

          <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
            <div className="flex flex-col items-center">
              <span className="text-[11px] font-medium text-neutral-400 uppercase tracking-wider mb-1">
                Medal
              </span>
              <div
                className={`w-11 h-11 rounded-full border-2 flex items-center justify-center font-bold text-xs shadow-inner ${getMedalColor()}`}
              >
                {medal === 'none' ? (
                  <span className="text-[10px]">-</span>
                ) : (
                  <Award className="w-5 h-5" />
                )}
              </div>
              <span className="text-[10px] uppercase font-bold text-neutral-400 mt-1">
                {medal === 'none' ? 'No Medal' : medal}
              </span>
            </div>

            <div className="flex flex-col items-end">
              <div className="mb-2">
                <div className="text-[10px] text-neutral-400 uppercase tracking-wider">
                  Score
                </div>
                <div className="text-3xl font-bold text-white font-mono tabular-nums">
                  {animatedScore}
                </div>
              </div>

              <div>
                <div className="text-[10px] text-neutral-400 uppercase tracking-wider">
                  Best
                </div>
                <div className="text-lg font-semibold text-amber-400 font-mono tabular-nums flex items-center gap-1 justify-end">
                  <Trophy className="w-3.5 h-3.5 text-amber-400" />
                  {highScore}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-2.5 text-[11px] text-neutral-400">
            {score < 10
              ? 'Reach 10 points to unlock Bronze Medal!'
              : score < 25
              ? 'Reach 25 points for Silver Medal!'
              : score < 50
              ? 'Reach 50 points for Gold Medal!'
              : score < 100
              ? 'Reach 100 points for Platinum Medal!'
              : 'Master flyer status achieved! 🏆'}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2">
          <button
            onClick={onRestart}
            className="w-full py-3 px-4 bg-emerald-500 hover:bg-emerald-400 active:scale-[0.98] text-neutral-950 font-bold rounded-lg transition-all flex items-center justify-center gap-2 shadow-lg cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>PLAY AGAIN</span>
          </button>

          <button
            onClick={handleShare}
            className="w-full py-2 px-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>{copied ? 'Copied to Clipboard!' : 'Share Run Result'}</span>
          </button>
        </div>

        <div className="mt-3 text-[10px] text-neutral-400">
          Press <kbd className="px-1 py-0.5 bg-neutral-800 rounded border border-neutral-700 text-neutral-300">Space</kbd> or Tap to retry
        </div>
      </div>
    </div>
  );
};
