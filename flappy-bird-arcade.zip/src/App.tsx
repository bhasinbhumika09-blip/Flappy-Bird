/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback } from 'react';
import { BirdSkinId, DifficultyMode, GameScoreEntry, GameState, GameStats, ThemeId } from './types/game';
import { BIRD_SKINS, DIFFICULTIES, getMedalTier } from './utils/constants';
import { sound } from './utils/audio';
import { FlappyCanvas } from './components/FlappyCanvas';
import { GameOverModal } from './components/GameOverModal';
import { CustomizerModal } from './components/CustomizerModal';
import { ScoreboardPanel } from './components/ScoreboardPanel';
import { HowToPlayModal } from './components/HowToPlayModal';
import { HeaderBar } from './components/HeaderBar';
import { Pause, Play, RotateCcw, Sliders, Trophy, Volume2, VolumeX } from 'lucide-react';

const STORAGE_KEY = 'flappy_bird_arcade_stats_v1';
const PREFS_KEY = 'flappy_bird_arcade_prefs_v1';

export default function App() {
  const [gameState, setGameState] = useState<GameState>('GET_READY');
  const [currentScore, setCurrentScore] = useState(0);
  const [lastGameOverScore, setLastGameOverScore] = useState(0);
  const [isNewHigh, setIsNewHigh] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  // Customization & Difficulty settings
  const [skinId, setSkinId] = useState<BirdSkinId>('classic_ruby');
  const [themeId, setThemeId] = useState<ThemeId>('day');
  const [difficulty, setDifficulty] = useState<DifficultyMode>('classic');
  const [isMuted, setIsMuted] = useState(false);

  // Modals & Panels
  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);
  const [isHowToPlayOpen, setIsHowToPlayOpen] = useState(false);
  const [showScoresMobile, setShowScoresMobile] = useState(false);

  // Career Statistics
  const [stats, setStats] = useState<GameStats>({
    highScore: 0,
    casualHighScore: 0,
    classicHighScore: 0,
    turboHighScore: 0,
    totalGames: 0,
    totalPipes: 0,
    recentRuns: [],
  });

  // Load preferences and stats on mount
  useEffect(() => {
    try {
      const savedStats = localStorage.getItem(STORAGE_KEY);
      if (savedStats) {
        setStats(JSON.parse(savedStats));
      }

      const savedPrefs = localStorage.getItem(PREFS_KEY);
      if (savedPrefs) {
        const prefs = JSON.parse(savedPrefs);
        if (prefs.skinId) setSkinId(prefs.skinId);
        if (prefs.themeId) setThemeId(prefs.themeId);
        if (prefs.difficulty) setDifficulty(prefs.difficulty);
        if (typeof prefs.isMuted === 'boolean') {
          setIsMuted(prefs.isMuted);
          sound.setMuted(prefs.isMuted);
        }
      }
    } catch {
      // LocalStorage fallback
    }
  }, []);

  // Save prefs when changed
  useEffect(() => {
    try {
      localStorage.setItem(
        PREFS_KEY,
        JSON.stringify({ skinId, themeId, difficulty, isMuted })
      );
    } catch {
      // ignore
    }
  }, [skinId, themeId, difficulty, isMuted]);

  // Handle Audio toggle
  const handleToggleMute = useCallback(() => {
    setIsMuted((prev) => {
      const next = !prev;
      sound.setMuted(next);
      return next;
    });
  }, []);

  // Handle Score update from canvas
  const handleScoreUpdate = useCallback((score: number) => {
    setCurrentScore(score);
  }, []);

  // Handle Game Over
  const handleGameOver = useCallback((finalScore: number) => {
    setLastGameOverScore(finalScore);
    setGameState('GAME_OVER');

    setStats((prev) => {
      let isHigh = false;
      let newHigh = prev.highScore;
      let newClassicHigh = prev.classicHighScore;
      let newCasualHigh = prev.casualHighScore;
      let newTurboHigh = prev.turboHighScore;

      if (difficulty === 'classic' && finalScore > prev.classicHighScore) {
        newClassicHigh = finalScore;
        isHigh = true;
      } else if (difficulty === 'casual' && finalScore > prev.casualHighScore) {
        newCasualHigh = finalScore;
        isHigh = true;
      } else if (difficulty === 'turbo' && finalScore > prev.turboHighScore) {
        newTurboHigh = finalScore;
        isHigh = true;
      }

      if (finalScore > prev.highScore) {
        newHigh = finalScore;
        isHigh = true;
      }

      setIsNewHigh(isHigh);
      if (isHigh && finalScore > 0) {
        sound.playNewHighScore();
      }

      const medal = getMedalTier(finalScore);
      const newEntry: GameScoreEntry = {
        id: `${Date.now()}-${Math.random()}`,
        score: finalScore,
        mode: difficulty,
        date: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        medal,
      };

      const updated: GameStats = {
        highScore: newHigh,
        casualHighScore: newCasualHigh,
        classicHighScore: newClassicHigh,
        turboHighScore: newTurboHigh,
        totalGames: prev.totalGames + 1,
        totalPipes: prev.totalPipes + finalScore,
        recentRuns: [newEntry, ...prev.recentRuns.slice(0, 19)],
      };

      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch {
        // ignore
      }

      return updated;
    });
  }, [difficulty]);

  // Restart handler
  const handleRestart = useCallback(() => {
    setGameState('GET_READY');
    setCurrentScore(0);
    setIsNewHigh(false);
  }, []);

  // Pause / Resume handler
  const handleTogglePause = useCallback(() => {
    if (gameState === 'PLAYING') {
      setIsPaused((prev) => !prev);
    }
  }, [gameState]);

  // Keyboard shortcut listener for 'P' (pause) and 'M' (mute)
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'p' || e.key === 'P') {
        handleTogglePause();
      } else if (e.key === 'm' || e.key === 'M') {
        handleToggleMute();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [handleTogglePause, handleToggleMute]);

  const activeSkin = BIRD_SKINS[skinId];
  const activeDiff = DIFFICULTIES[difficulty];

  // Current mode's best score
  const modeHighScore =
    difficulty === 'classic'
      ? stats.classicHighScore
      : difficulty === 'casual'
      ? stats.casualHighScore
      : stats.turboHighScore;

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-['Outfit'] antialiased selection:bg-amber-400 selection:text-neutral-950">
      {/* Top Bar following Top Bar Contract */}
      <HeaderBar
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onOpenCustomizer={() => setIsCustomizerOpen(true)}
        onOpenHowToPlay={() => setIsHowToPlayOpen(true)}
        onToggleScores={() => setShowScoresMobile((prev) => !prev)}
        showingScores={showScoresMobile}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 py-6 flex flex-col lg:flex-row items-center lg:items-start justify-center gap-8">
        {/* Left Column: Arcade Cabinet Frame & Canvas */}
        <div className="flex flex-col items-center w-full max-w-[390px]">
          {/* Arcade Machine Top Header Bezel */}
          <div className="w-full bg-neutral-900 border border-neutral-800 rounded-t-2xl px-4 py-2.5 flex items-center justify-between text-xs text-neutral-400 shadow-md">
            <div className="flex items-center gap-2">
              <span
                className="w-2.5 h-2.5 rounded-full"
                style={{ backgroundColor: activeSkin.primaryColor }}
              />
              <span className="font-medium text-white">{activeSkin.name}</span>
              <span className="text-neutral-600">·</span>
              <span className="capitalize">{activeDiff.name}</span>
            </div>

            <div className="flex items-center gap-1.5 font-mono text-neutral-300">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-amber-400 font-bold tabular-nums">
                {modeHighScore || 0}
              </span>
            </div>
          </div>

          {/* Interactive Canvas Container with Overlays */}
          <div className="relative w-full flex justify-center bg-neutral-900 border-x border-neutral-800 p-2 sm:p-3 shadow-2xl">
            <FlappyCanvas
              gameState={gameState}
              onGameStateChange={setGameState}
              onScoreUpdate={handleScoreUpdate}
              onGameOver={handleGameOver}
              skinId={skinId}
              themeId={themeId}
              difficulty={difficulty}
              isPaused={isPaused}
            />

            {/* Game Over Modal Overlay */}
            {gameState === 'GAME_OVER' && (
              <GameOverModal
                score={lastGameOverScore}
                highScore={modeHighScore}
                isNewHigh={isNewHigh}
                difficulty={difficulty}
                onRestart={handleRestart}
              />
            )}

            {/* In-game Pause Banner */}
            {isPaused && gameState === 'PLAYING' && (
              <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex flex-col items-center justify-center p-4 z-20 rounded-2xl">
                <div className="bg-neutral-900 border border-neutral-700 px-6 py-4 rounded-xl shadow-2xl flex flex-col items-center">
                  <h3 className="text-base font-bold text-white mb-2 font-['Press_Start_2P'] text-sm">
                    PAUSED
                  </h3>
                  <p className="text-xs text-neutral-400 mb-4">Take a breather</p>
                  <button
                    onClick={() => setIsPaused(false)}
                    className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Play className="w-3.5 h-3.5" />
                    Resume Flight
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Arcade Cabinet Control Deck Bezel */}
          <div className="w-full bg-neutral-900 border border-neutral-800 rounded-b-2xl p-3 flex items-center justify-between shadow-lg">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsCustomizerOpen(true)}
                title="Hangar & Difficulty"
                className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-750 text-neutral-200 text-xs font-medium rounded-lg border border-neutral-700/80 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Sliders className="w-3.5 h-3.5 text-neutral-400" />
                <span>Hangar</span>
              </button>

              {gameState === 'PLAYING' && (
                <button
                  onClick={handleTogglePause}
                  title="Pause (P)"
                  className="p-1.5 bg-neutral-800 hover:bg-neutral-750 text-neutral-200 rounded-lg border border-neutral-700/80 transition-colors cursor-pointer"
                >
                  {isPaused ? <Play className="w-4 h-4 text-emerald-400" /> : <Pause className="w-4 h-4" />}
                </button>
              )}

              {gameState === 'GAME_OVER' && (
                <button
                  onClick={handleRestart}
                  title="Retry"
                  className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retry</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-3 text-xs text-neutral-400">
              <span className="hidden sm:inline text-[11px]">
                <kbd className="px-1.5 py-0.5 bg-neutral-950 rounded border border-neutral-800 text-neutral-300 font-mono">
                  Space
                </kbd>{' '}
                to Flap
              </span>

              <button
                onClick={handleToggleMute}
                className="text-neutral-400 hover:text-white transition-colors cursor-pointer p-1"
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Scoreboard, Career Stats & Information */}
        <div
          className={`w-full max-w-[380px] lg:block ${
            showScoresMobile ? 'block' : 'hidden'
          }`}
        >
          <ScoreboardPanel
            stats={stats}
            onClearHistory={() => {
              const reset = { ...stats, recentRuns: [] };
              setStats(reset);
              localStorage.setItem(STORAGE_KEY, JSON.stringify(reset));
            }}
          />
        </div>
      </main>

      {/* Bottom Footer */}
      <footer className="w-full py-4 border-t border-neutral-900 text-center text-xs text-neutral-500">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Retro arcade canvas physics engine · Pure Web Audio synthesized SFX</span>
          <span>Zero external dependencies · High-DPI Retina ready</span>
        </div>
      </footer>

      {/* Modals */}
      <CustomizerModal
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        selectedSkin={skinId}
        onSelectSkin={setSkinId}
        selectedTheme={themeId}
        onSelectTheme={setThemeId}
        selectedDifficulty={difficulty}
        onSelectDifficulty={setDifficulty}
      />

      <HowToPlayModal
        isOpen={isHowToPlayOpen}
        onClose={() => setIsHowToPlayOpen(false)}
      />
    </div>
  );
}
